
const userAccessToken = "";
const clientID = "99f7afb2114045ff935df101b53fc1a4";
const redirectURI = "http://localhost:3000/";

//https://accounts.spotify.com/authorize?client_id=99f7afb2114045ff935df101b53fc1a4&response_type=token&scope=playlist-modify-public&redirect_uri=http://localhost:3000/

//https://accounts.spotify.com/authorize?client_id=CLIENT_ID&response_type=token&scope=playlist-modify-public&redirect_uri=REDIRECT_URI

const Spotify = {



  getAccessToken() {
    if(userAccessToken) {
      return userAccessToken;
    }
    const url = window.location.href;
    const accessTokenRegEx = url.match(/access_token=([^&]*)/);
    const tokenExpiresInRegEx = url.match(/expires_in=([^&]*)/);
    let accessToken;
    let tokenExpiresIn;

    if (accessTokenRegEx && tokenExpiresInRegEx) {
      accessToken = accessTokenRegEx[1];
      tokenExpiresIn = Number(tokenExpiresInRegEx[1]);
      window.setTimeout(() => accessToken = '', tokenExpiresIn * 1000);
      window.history.pushState('Access Token', null, '/');
      return accessToken;
    } else {
      //redirect to spotify accounts page:
      window.location = `https://accounts.spotify.com/authorize?client_id=${clientID}&response_type=token&scope=playlist-modify-public&redirect_uri=${redirectURI}`;
    }
  },

  async search(term) {

    const endpoint = `https://api.spotify.com/v1/search?type=track&q=${term}`;
    const accessToken = this.getAccessToken();
    console.log(accessToken);

    try {
    const response = await fetch( endpoint, {headers: {Authorization: `Bearer ${accessToken}`} } );
    console.log('response:', response);
    if (response.ok) {
      const jsonResponse = await response.json();
      console.log('json response:', jsonResponse);
      if (!jsonResponse.tracks) {
        return [];
      } else {
        const tracksArray = jsonResponse.tracks.items.map(track => {
          return {
            id: track.id,
            name: track.name,
            album: track.album.name,
            artist: track.artists[0].name,
            uri: track.uri
          };
        } );
        return tracksArray;
      }
    }
  } catch (error) {
    console.log(error);
  }

    /* return fetch(endpoint, {
        headers: {Authorization: `Bearer ${accessToken}`}
      }
    ).then( response => {
        console.log('Hi, 1st then statement was a success: returned value:', response);
        return response.json();
      }, err => console.log('1st then statement returned an error, error code:', err)
    ).then( jsonResponse => {
        console.log('Hi, 2nd then statement was a success: returned value:', jsonResponse);
        if (!jsonResponse.tracks) {
          return [];
        }
        const tracksArray = jsonResponse.tracks.items.map(track => {
          return {
            id: track.id,
            name: track.name,
            album: track.album.name,
            artist: track.artists[0].name,
            uri: track.uri
          };
        } );
        console.log('spotify.search succeeded and returned following object (should be an array of track objects):', tracksArray);
        return tracksArray;
      }, err => console.log('2nd then statement returned an error, error code:', err) ); */
  },

  async savePlaylist(playlistName, playlistTrackURIs) {

    if (playlistName && playlistTrackURIs) {
      const accessToken = this.getAccessToken();
      const headers = {Authorization: `Bearer ${accessToken}`};
      let userID;

      try {

        const response = await fetch('https://api.spotify.com/v1/me', {headers: headers} );

        if (response.ok) {

          const jsonResponse = await response.json();
          userID = jsonResponse.id;

          try {

            const response = await fetch(`https://api.spotify.com/v1/users/${userID}/playlists`,
              {
                headers: headers,
                method: 'POST',
                body: JSON.stringify( {name: playlistName} )
              });

              if (response.ok) {

                const jsonResponse = await response.json();
                const playlistID = jsonResponse.id;
                return fetch(`https://api.spotify.com/v1/users/${userID}/playlists/${playlistID}/tracks`,
                {
                  headers: headers,
                  method: 'POST',
                  body: JSON.stringify( {uris: playlistTrackURIs} )
                })

              }

          } catch(error) {
            console.log(error);
          }

        }

      } catch(error) {
        console.log(error);
      }
    } else {
      return;
    }

      /*
      if (playlistName && playlistTrackURIs) {
        const accessToken = this.getAccessToken();
        const headers = {Authorization: `Bearer ${accessToken}`};
        let userID;

      return fetch ('https://api.spotify.com/v1/me', {headers: headers} )
      .then(response => {
          return response.json();
        })
      .then(jsonResponse => {
        userID = jsonResponse.id;
        return fetch(`https://api.spotify.com/v1/users/${userID}/playlists`,
          {
            headers: headers,
            method: 'POST',
            body: JSON.stringify( {name: playlistName} )
          })
          .then(response => response.json())
          .then(jsonResponse => {
            const playlistID = jsonResponse.id;
            return fetch(`https://api.spotify.com/v1/users/${userID}/playlists/${playlistID}/tracks`,
            {
              headers: headers,
              method: 'POST',
              body: JSON.stringify( {uris: playlistTrackURIs} )
            });
          });
      });
    } else {
      return;
    }
    */
  }

}

export default Spotify;
